Usage of the testing files. 

Hierarchy
1. experiments % the experiments for TAuth
*.tv files are the models for TAuth. The files inside the out directory are the experiment results presented in the paper. If you want to rerun the experiments, please put the binary file into the experiments directory and run the tesh.sh shell program. The experiments result will be updated in the out directory.  
2. comparisons % the comparisons between TAuth, ProVerif and Scyther
In each directory, the models are presented and the experiment results are resident in the out directory. If you want to rerun the experiments, please put the corresponding binary files into corresponding directories and run the test.sh shell program. The results will be updated in the out directories. 
    