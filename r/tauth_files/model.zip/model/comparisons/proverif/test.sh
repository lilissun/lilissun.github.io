#!/bin/bash

mkdir -p out

for file in `find . -name '*.pv'`
do
echo "Processing $file"
{ time ./proverif $file ; } > out/`basename $file`.po 2> out/`basename $file`.ti
done