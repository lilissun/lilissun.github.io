#!/bin/bash

mkdir -p out

for file in `find . -name '*.spdl'`
do
echo "Processing $file"
{ time ./scyther $file ; } > out/`basename $file`.so 2> out/`basename $file`.ti
done