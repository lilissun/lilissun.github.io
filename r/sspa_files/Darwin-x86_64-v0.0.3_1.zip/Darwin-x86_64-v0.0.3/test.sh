#!/bin/bash

mkdir -p result

for file in `find examples -name '*.sv'`
do
echo "Processing $file"
./sspa $file > result/`basename $file`.so
done